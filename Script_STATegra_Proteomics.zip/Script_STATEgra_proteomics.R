#######################################################################
#######         PRE-PROCESSING Proteomics STATegra DATA          #######       
#######################################################################

## By Andreas Schmidt A.Schmidt@med.uni-muenchen.de, David Gomez-Cabrero and Ana Conesa; 

# Raw data are available through ProteomeXchage PXD003263

####  FROM RAW DATA TO PROTEIN QUANTIFICATION   ####
#####################################################

##Proteomics data were acquired in three technical repeats of a 1D reversed phase separation of the 
# complete cellular proteome on an nano-chromatography system coupled to  an LTQ Orbitrap hybrid mass spectrometer.
# Initial protein mapping to a fasta protein sequence database generated from the RNA-seq data of the STATegra project 
# using the MaxQuant database search software (vs 1.5.0.0; https://maxquant.org/). ####

###MaxQuant database search settings

# FDR rates
# PSM FDR   0.01 
# Protein FDR	0.02
# Site FDR 	0.05

# Result filters
# Min. peptide length	7
# Min. peptide score	15
#Min. # of razor peptides	1

### Variable modifications
### Acetylation of protein N-terminus
### Oxidation of methionine

### Database search was performed against a concatenated forward/reversed library to determine the score distribution 
# of reversed peptide sequences (true negatives) serving as a model for FDR filtering. 
# Further parameters can be found in the corresponding parameter.txt and summary.txt file included in the repository.

### Protein quantitation is part of the search algorithm which extracts the chromatographic peak area of each peptide signal. 
# Peptide peaks of identified sequences are summed up to obtain the protein intensity values. 
# Intensity values were automatically converted to iBAQ values by dividing by the number of expected tryptic peptides for the 
# corresponding protein amino acid sequence. 
# Protein results are written into the protein.groups.txt file including quantitation results after FDR filtering. 


### The results are written into the Proteomics_01_uniprot_canonical_normalized.txt


#### THIS PORTION OF THE SCRIPT IS RUN IN R USING A .R SCRIPT ####
##################################################################

library(NOISeq)
library(MixOmics)

#### STEP 1: LOAD THE DATA
#### 
proteomics= read.delim(paste( "Proteomics_01_uniprot_canonical_normalized.txt",sep=""), as.is = TRUE, header = TRUE, sep = "\t"); dim(proteomics) # 2191 dim(proteomics)
colnames(proteomics)
data = proteomics[1:2527,51:86] ; dim (data)# 2527 36  # extract true values
names = paste("prot", formatC(1:nrow(data), digits = 3, flag = 0), sep = "_")
rownames(data) = names
all.names <- proteomics[1:2527,1:7]
rownames(all.names) = names
colnames(data) = lapply(colnames(data), function (x) strsplit(x, ".", fixed = TRUE)[[1]][3])
colnames(data) = lapply(colnames(data), function (x) substr(x, 4, nchar(x)))
data[data == 0] <- NA
head(data)


#### STEP 2:  DESIGN
####
data = data[,c(2*(1:18)-1, 2*(1:18))] 
colnames(data) = sapply(colnames(data), function (x) sub( "batch", "",x))
design = data.frame("treat" = sapply(colnames(data), function (x) substr(x, 1, 3)),
                     "time" = as.numeric(sapply(sapply(colnames(data), function (x) strsplit(x, "_")[[1]][2]),
                                                function (x) strsplit(x, "h")[[1]][1])),
                     "Brep" = sapply(colnames(data), function (x) substr(x, nchar(x), nchar(x))))
design = data.frame(design, "cond" = apply(design[,1:2], 1, paste, collapse = ""))
design

#### STEP 3: REPORTER GENES
####
reporter.genes <- c("Ldha", "Igll1","Slc7a5","Hk2","Runx1","Pax5")

view.reporter <- function (data, reporter, one.series = F, cond =design$cond , mylegend = "Ik/Ctrl") {
  repo.prots <- na.omit(rownames(all.names)[match(reporter.genes, all.names$Gene.names)])
  repo.data <- data[intersect(repo.prots, rownames(data)),]
  ave.data <- t(apply(repo.data, 1, function (x) tapply(x,cond,mean, na.rm = T)))
  print(ave.data)
  cols <- colnames(ave.data)
  time <- c(0,2,5,12,18,24)
  colors <- c("red", 'blue')
  par(mfrow = c(3,2))
  for (i in 1:length(repo.prots)) {
    plot(time, y = rep(1, length(time)), ylim = c(min(ave.data[i,], na.rm = T), max(ave.data[i,], na.rm = T)), ty = "l", ylab = "Expression", col = "white",,main = reporter.genes[i])
    ik.data <- ave.data[i,1:6]
    lines(time[!is.na(ik.data)], ik.data[!is.na(ik.data)], col = colors[1])
    if (one.series == F) {
      y.data <- ave.data[i,7:12]
      lines(time[!is.na(y.data)], y.data[!is.na(y.data)], col = colors[2])
      legend("topright", legend = c( "Ikaros", "Control"), text.col = colors)
    } else {
      legend("topright", legend = mylegend)
    }
  }  
}


## Visual check
boxplot(as.matrix(data)~col(data), names = colnames(data), las = 2, col = rep(c(1:6), each = 3))
view.reporter(data = data, reporter.genes)

# All genes down at Ikaros, possibly normalisation issue

#### STEP 4: LOG-TRANSFORMATION
####

## Log transformation
data[data == 0] <- NA
data.norm = log2(data)
head(data.norm)
boxplot(as.matrix(data.norm)~col(data.norm), names = colnames(data.norm), las = 2, col = rep(c(1:6), each = 3))
view.reporter(data.norm, reporter.genes)

#### STEP 5: BRING ALL SAMPLES TO EQUAL MEAN OF MEDIANS
####
median <- apply(data.norm, 2, median, na.rm = T) # median per sample
means.of.medians <- tapply(median, design$cond, mean) [c(7:12,1:6)]
means.of.medians.vector <- rep(means.of.medians, each = 3)
means.of.medians.deviation <-median-means.of.medians.vector
means.of.medians.deviation.matrix <- matrix(data = rep(means.of.medians.deviation, nrow(data.norm)), 
                                            nrow = nrow(data.norm), ncol = ncol(data.norm), byrow = T)
data.norm.mean.median <- data.norm - means.of.medians.deviation.matrix
par(mfrow = c(2,2))
boxplot(as.matrix(data.norm)~col(data.norm), names = colnames(data.norm), las = 2, col = rep(c(1:6), each = 3))
boxplot(as.matrix(data.norm.mean.median)~col(data.norm.mean.median), names = colnames(data.norm), las = 2, col = rep(c(1:6), each = 3))

view.reporter(data.norm.mean.median, reporter.genes)


#### STEP 6: MISSING VALUES: DISCARD AND IDENTIFICATION
####

## 6.1 Identification of proteins with no missing values
noNA = na.omit(data.norm.mean.median)
nrow(noNA)  # 612 proteins without any missing

## 6.2 Characterisation of missing values
# Computing a matrix of how many NAs we have per condition at each gene

NAstat = matrix(NA, ncol = 12, nrow = nrow(data.norm))
ncond = unique(design[,"cond"])
for (i in 1:nrow(NAstat)) {
  for (j in 1:length(ncond)) {
    NAstat[i,j] = sum(is.na(data.norm[i,grep(ncond[j], design[,"cond"])]))
  }
}
colnames(NAstat) = ncond
rownames(NAstat) = rownames(data.norm)
head(NAstat)

## 6.3 Filtering based on  criteria: 3 misings per group in at least 11 group
discard = which(apply(NAstat, 1, function (x) length(which(x>2))>10))  # 3 misings in at least 11 samples
data.norm2 = data.norm.mean.median[-discard,] ;dim (data.norm2 ) #  2396 proteins remaining with at least 1 value in 10 conditions
NAstat2 = NAstat[-discard,]


#### STEP 7: IMPUTATION
####

## 7.1: Imputation of all NA in a given condition:
# Computing the lowest value per sample

mins <- apply(data.norm2, 2, min, na.rm = TRUE) ; mins

	#When IK is NA for all samples, the value is replaced with min/2 + a "random value below discovery" 
	#When Control is NA for all samples, the value is replaced with min/2 + a "random value below discovery" 

std.distr = apply(data.norm2,1, function (x) {tapply(x, design[,"cond"], sd, na.rm = T)} )# sd within conditions
allNACtr = allNATr  = NULL
for (i in 1 : nrow (data.norm2)) {
  if (all(NAstat2[i, 1:6] == 3)) { # if all controls are NA for all 3 replicates
    allNACtr <- c(allNACtr, i) # keep gene number
      for (j in rep(c(1:6), each = 3)) {
        data.norm2 [i,j] <- rnorm (1,mins[j]/2,median(std.distr, na.rm = T)) 
      }
    #distr = rnorm (180,mins,median(std.distr))  # 180 values around 0 with std our std
    #data.norm2 [i,1:18] <- distr[which(distr>0)][1:18] # assign positive values
  }
  if (all(NAstat2[i, 7:12] == 3)) { # the same is done for the Treatment
    allNATr <- c(allNATr, i)
    for (j in rep(c(7:12), each = 3)) {
      data.norm2 [i,j] <- rnorm (1,mins[j]/2,median(std.distr, na.rm = T)) 
    }
    #distr= rnorm (180,0,median(std.distr, na.rm = T)) 
    #data.norm2 [i,19:36] <- distr[which(distr>0)][1:18] 
  }
}

length(allNACtr) # 21 prots where all Control values were NA and now have values around 0
length(allNATr) # 36 prots where all Control values were NA and nowhave values around 0
boxplot(as.matrix(data.norm2)~col(data.norm2), names = colnames(data.norm), las = 2, col = rep(c(1:6), each = 3))
view.reporter(data = data.norm2, reporter.genes)


## 7.2: Recomputing NA:

NAstat3 = matrix(NA, ncol = 12, nrow = nrow(data.norm2))
ncond = unique(design[,"cond"])

for (i in 1:nrow(NAstat3)) {
  for (j in 1:length(ncond)) {
    NAstat3[i,j] = sum(is.na(data.norm2[i,grep(ncond[j], design[,"cond"])]))
  }
}
colnames(NAstat3) = ncond
rownames(NAstat3) = rownames(data.norm2)
head (NAstat3)

## Identification of proteins with no missing values
noNA = na.omit(data.norm2)
nrow(noNA)  # still 612 proteins without any missing


## 7.3: Imputing for those conditions with only 1 NA: by the mean of the condition.

data.norm3 = data.norm2
head(NAstat3)

for ( i in 1: nrow(data.norm3)) {
  for (j in seq(1,34, by=3)) {
    gene.cond <- data.norm3[i,c(j:(j+2))]
    my.na <- which(is.na (gene.cond))
    if(length(which(is.na (gene.cond))) == 1) {
      gene.mean <- mean(as.numeric(gene.cond), na.rm = T)
      data.norm3[i,j+my.na-1] <- rnorm (1,gene.mean,median(std.distr, na.rm = T)) 
    }    
  }
}

noNA3 = na.omit(data.norm3); nrow(noNA3)  # 864  # we increased around 200 proteins now having complete values

### 7.4  Visual analysis of imputation results
par(mfrow = c(2,2))
mycol = rep(rainbow(6), each = 3)
mycol[mycol == "#FFFF00FF"] = "orange"
boxplot (as.matrix(noNA3)~col(noNA3), names = colnames(data.norm), las = 2, col = mycol, main = "Proteomics Imputed ")
pca.result <- pca(t(noNA3), center = TRUE, scale = FALSE)
plotIndiv(pca.result, col = mycol, style = "graphics" , title = "Proteomics Imputed ", size.title = 1)
noNA3.ratio <- noNA3[,19:36] - noNA3[,1:18] # calculating ratios
pca.result <- pca(t(noNA3.ratio), center = TRUE, scale = FALSE)
plotIndiv(pca.result, col = mycol, style = "graphics", title = "Proteomics Imputed Ratios", size.title = 1)
pca.result <- pca(t(noNA3[,19:36]), center = TRUE, scale = FALSE)  # Only Ikaros
plotIndiv(pca.result, col = mycol, style = "graphics", title = "Proteomics Imputed Ikaros", , size.title = 1)
view.reporter(data = noNA3, reporter.genes)

### 7.5 Conclusions
  # Most replicates cluster together
  # Time point 2 is funny and drives the PCA
  # When used Ikaros alone, only time point 24 h. is different


#### STEP 8: TMM normalisation of imputed data
noNA3_tmmNorm = tmm(noNA3)

### 8.1 Visual analysis of results
par(mfrow = c(2,2))
boxplot (as.matrix(noNA3_tmmNorm)~col(noNA3_tmmNorm), names = colnames(data.norm), las = 2, col = mycol, main = "Proteomics Imputed TMM")
plotIndiv(pca(t(noNA3_tmmNorm), center = TRUE, scale = FALSE), col = mycol, style = "graphics" , title = "Proteomics Imputed TMM", size.title = 1)
noNA3.ratio.tmm <- noNA3_tmmNorm[,19:36] - noNA3_tmmNorm[,1:18] # calculating ratios
plotIndiv(pca(t(noNA3.ratio), center = TRUE, scale = FALSE), col = mycol, style = "graphics", title = "Proteomics Imputed Ratios TMM", size.title = 1)
plotIndiv(pca(t(noNA3_tmmNorm[,19:36]), center = TRUE, scale = FALSE), col = mycol, style = "graphics", title = "Proteomics Imputed Ikaros TMM", , size.title = 1)  # Only Ikaros
view.reporter(data = noNA3_tmmNorm, reporter.genes)


# Conclusions
# Applying TMM the global downregulation of Ikaros 24 hours is removed, however, marker genes remain OK.



#### STEP 7: OUTCOME
data.norm3.names <- cbind(all.names[rownames(data.norm3),], data.norm3) # add all protein names
noNA3_tmmNorm.names <- cbind(all.names[rownames(noNA3_tmmNorm),], noNA3_tmmNorm) # add all protein names
noNA3.names <- cbind(all.names[rownames(noNA3),], noNA3) # add all protein names

write.table(noNA3_tmmNorm.names, "STATegra_Proteomics_imputed_no_missings_tmm.txt", sep= "\t", row.names = F, col.names = T, quote = F)
write.table(data.norm3.names, "STATegra_Proteomics_NOT_imputed.txt", sep= "\t", row.names = F, col.names = T, quote = F)
write.table(noNA3.names, "STATegra_Proteomics_imputed_no_missing.txt", sep= "\t", row.names = F, col.names = T, quote = F)


data <- read.delim("STATegra_Proteomics_NOT_imputed.txt")

Hk2 <- data.norm3[data.norm3$Gene.names == "Hk2",14:43]
Hk2
